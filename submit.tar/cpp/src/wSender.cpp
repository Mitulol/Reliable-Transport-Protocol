#include <iostream>
#include <cstring>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

int main() {
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    struct sockaddr_in receiverAddr;
    memset(&receiverAddr, 0, sizeof(receiverAddr));
    receiverAddr.sin_family = AF_INET;
    receiverAddr.sin_port = htons(8000);
    inet_pton(AF_INET, "127.0.0.1", &receiverAddr.sin_addr);

    const char* msg = "Hello!";
    sendto(sockfd, msg, strlen(msg), 0, (struct sockaddr*)&receiverAddr, sizeof(receiverAddr));

    std::cout << "Sent message: " << msg << std::endl;
    close(sockfd);
    return 0;
}
